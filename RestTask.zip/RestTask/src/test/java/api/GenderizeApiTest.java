package api;

import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.Test;
import static io.restassured.RestAssured.given;
import static io.restassured.RestAssured.when;
import static org.hamcrest.Matchers.equalTo;

public class GenderizeApiTest extends BaseTest {

    @Test(description = "Validate status code is 200")
    void statusCodeTC() {
        Response response = getGenderResponse("luc");
        Assert.assertEquals(response.statusCode(), 200);
    }

    @Test(description = "validate error message {Missing 'name' parameter} when sending no parameter")
    void validateEmptyNameErrorTC() {
        Response response = given().when().get(baseUrl);
        Assert.assertEquals(getJson(response).getString("error"), "Missing 'name' parameter");
    }

    @Test(description = "Validate probability is between 0 and 1")
    void validateProbabilityTC() {
        Response response = getGenderResponse("luc");
        double probability = getJson(response).getDouble("probability");
        Assert.assertTrue(probability >= 0 && probability <= 1);
    }

    //example for validation using hamcrest Matcher library
    @Test(description = "Validate luc gender is male")
    void validateGenderTC() {
        given().queryParam("name", "luc")
                .when().get(baseUrl)
                .then()
                .body("gender", equalTo("male"));
    }

    @Test(description = "Validate count is > 0 when sending name=luc")
    void validateCountTC() {
        Response response = getGenderResponse("luc");
        Assert.assertTrue(getJson(response).getInt("count")>0);
    }

    @Test(description = "Validate response name is luc")
    void validateNameTC() {
        Response response = getGenderResponse("luc");
        Assert.assertEquals(getJson(response).getString("name"), "luc");
    }

    @Test(description = "Validate count data type is integer")
    void validateCountDataType() {
        Response response = getGenderResponse("luc");
        Assert.assertEquals(getJson(response).get("count").getClass(), Integer.class);
    }

    @Test(description = "Validate probability data type is float")
    void validateProbabilityDataType() {
        Response response = getGenderResponse("luc");
        Assert.assertEquals(getJson(response).get("probability").getClass(), Float.class);
    }

    @Test(description = "Validate gender data type is string")
    void validateGenderDataType() {
        Response response = getGenderResponse("luc");
        Assert.assertEquals(getJson(response).get("gender").getClass(), String.class);
    }

    @Test(description = "Validate name data type is string")
    void validateNameDataType() {
        Response response = getGenderResponse("luc");
        Assert.assertEquals(getJson(response).get("name").getClass(), String.class);
    }

    @Test(description = "Validate empty name returns null gender")
    void validateEmptyNameTC() {
        Response response = getGenderResponse("");
        Assert.assertNull(getJson(response).getString("gender"));
        Assert.assertEquals(getJson(response).getDouble("probability"), 0.0);
    }

    @Test(description = "Validate numeric name returns null gender")
    void validateNumericNameTC() {
        Response response = getGenderResponse("123");
        Assert.assertNull(getJson(response).getString("gender"));
        Assert.assertEquals(getJson(response).getDouble("probability"), 0.0);
    }

    @Test(description = "Validate special characters name returns null gender")
    void validateSpecialCharactersNameTC() {
        Response response = getGenderResponse("$%^$^#$#");
        Assert.assertNull(getJson(response).getString("gender"));
        Assert.assertEquals(getJson(response).getDouble("probability"), 0.0);
    }

    @Test(description = "Validate space name returns null gender")
    void validateSpaceNameTC() {
        Response response = getGenderResponse("  ");
        Assert.assertNull(getJson(response).getString("gender"));
        Assert.assertEquals(getJson(response).getDouble("probability"), 0.0);
    }

    @Test(description = "validate send eman returns female gender")
    void validateFemaleNameTC() {
        Response response = getGenderResponse("eman");
        Assert.assertEquals(getJson(response).getString("gender"), "female");
    }

    @Test(description = "validate send مصطفي returns male gender")
    void validateArabicMaleNameTC() {
        Response response = getGenderResponse("مصطفي");
        Assert.assertEquals(getJson(response).getString("gender"), "male");
    }

    @Test(description = "validate send هاجر returns female gender")
    void validateArabicFemaleNameTC() {
        Response response = getGenderResponse("هاجر");
        Assert.assertEquals(getJson(response).getString("gender"), "female");
    }

    //corner case should validate according to documentation
    @Test(description = "validate send unisex name")
    void validateUnisexNameTC() {
        Response response = getGenderResponse("Nour");
        System.out.println(getJson(response).getString("gender"));
    }
}