package api;

import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

import static io.restassured.RestAssured.given;

public class BaseTest {
    protected final String baseUrl = "https://api.genderize.io";

    protected Response getGenderResponse(String name) {
        return given().queryParam("name", name)
                .when()
                    .get(baseUrl);
    }

    protected JsonPath getJson(Response response) {
        return response.jsonPath();
    }
}
